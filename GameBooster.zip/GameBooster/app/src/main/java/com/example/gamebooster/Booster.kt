package com.example.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager

data class RamInfo(val totalMb: Long, val availMb: Long) {
    val usedPercent: Int
        get() = if (totalMb == 0L) 0 else (((totalMb - availMb) * 100) / totalMb).toInt()
}

data class BatteryInfo(val level: Int, val tempC: Float)

data class GameApp(val name: String, val packageName: String)

object Booster {

    fun ramInfo(ctx: Context): RamInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamInfo(mi.totalMem / 1_048_576, mi.availMem / 1_048_576)
    }

    /** Menutup proses latar belakang aplikasi non-sistem. Mengembalikan (jumlah aplikasi, MB RAM yang dibebaskan). */
    fun cleanRam(ctx: Context): Pair<Int, Long> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ramInfo(ctx).availMb
        var count = 0
        for (app in ctx.packageManager.getInstalledApplications(0)) {
            if (app.packageName == ctx.packageName) continue
            if (app.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            am.killBackgroundProcesses(app.packageName)
            count++
        }
        Thread.sleep(600)
        val after = ramInfo(ctx).availMb
        return count to (after - before).coerceAtLeast(0)
    }

    @Suppress("DEPRECATION")
    fun installedGames(ctx: Context): List<GameApp> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter {
                pm.getLaunchIntentForPackage(it.packageName) != null &&
                    (it.category == ApplicationInfo.CATEGORY_GAME ||
                        it.flags and ApplicationInfo.FLAG_IS_GAME != 0)
            }
            .map { GameApp(pm.getApplicationLabel(it).toString(), it.packageName) }
            .sortedBy { it.name.lowercase() }
    }
}

object Monitor {
    fun battery(ctx: Context): BatteryInfo {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return BatteryInfo(if (scale > 0) level * 100 / scale else 0, temp)
    }
}

object GameMode {
    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun hasAccess(ctx: Context) = nm(ctx).isNotificationPolicyAccessGranted

    /** Aktifkan/matikan Jangan Ganggu agar notifikasi tidak mengganggu saat bermain. */
    fun setEnabled(ctx: Context, on: Boolean) {
        nm(ctx).setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_NONE
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }
}
