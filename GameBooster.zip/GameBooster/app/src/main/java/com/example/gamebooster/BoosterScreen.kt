package com.example.gamebooster

import android.content.Intent
import android.provider.Settings
import android.view.Choreographer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BoosterScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var ram by remember { mutableStateOf(Booster.ramInfo(ctx)) }
    var battery by remember { mutableStateOf(Monitor.battery(ctx)) }
    var fps by remember { mutableIntStateOf(0) }
    var gameMode by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Siap bermain") }
    var cleaning by remember { mutableStateOf(false) }
    val games = remember { Booster.installedGames(ctx) }

    // Perbarui RAM dan baterai setiap 2 detik
    LaunchedEffect(Unit) {
        while (true) {
            ram = Booster.ramInfo(ctx)
            battery = Monitor.battery(ctx)
            delay(2000)
        }
    }

    // Hitung frame per detik layar aplikasi ini lewat Choreographer
    DisposableEffect(Unit) {
        var frames = 0
        var last = 0L
        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (last == 0L) last = frameTimeNanos
                frames++
                if (frameTimeNanos - last >= 1_000_000_000L) {
                    fps = frames
                    frames = 0
                    last = frameTimeNanos
                }
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
        Choreographer.getInstance().postFrameCallback(cb)
        onDispose { Choreographer.getInstance().removeFrameCallback(cb) }
    }

    suspend fun boost() {
        cleaning = true
        status = "Membersihkan RAM..."
        val (count, freed) = withContext(Dispatchers.Default) { Booster.cleanRam(ctx) }
        ram = Booster.ramInfo(ctx)
        status = "Selesai: $count aplikasi ditutup, ±$freed MB dibebaskan"
        cleaning = false
    }

    fun launchGame(pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Game Booster", style = MaterialTheme.typography.headlineMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("RAM terpakai: ${ram.usedPercent}% (${ram.totalMb - ram.availMb} / ${ram.totalMb} MB)")
                LinearProgressIndicator(
                    progress = { ram.usedPercent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("FPS layar: $fps")
                    Text("Suhu: ${"%.1f".format(battery.tempC)}°C")
                    Text("Baterai: ${battery.level}%")
                }
            }
        }

        Button(
            onClick = { scope.launch { boost() } },
            enabled = !cleaning,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (cleaning) "Memproses..." else "Bersihkan RAM") }

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Mode Game", style = MaterialTheme.typography.titleMedium)
                    Text("Matikan notifikasi (Jangan Ganggu)", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = gameMode,
                    onCheckedChange = { on ->
                        if (!GameMode.hasAccess(ctx)) {
                            status = "Izinkan akses Jangan Ganggu untuk aplikasi ini, lalu coba lagi"
                            ctx.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } else {
                            GameMode.setEnabled(ctx, on)
                            gameMode = on
                            status = if (on) "Mode Game aktif" else "Mode Game nonaktif"
                        }
                    }
                )
            }
        }

        Text(status, style = MaterialTheme.typography.bodyMedium)

        Text("Game terpasang", style = MaterialTheme.typography.titleMedium)
        if (games.isEmpty()) {
            Text("Tidak ada game terdeteksi.", style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(games, key = { it.packageName }) { g ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(g.name, Modifier.weight(1f))
                        OutlinedButton(onClick = { launchGame(g.packageName) }) { Text("Main") }
                        Row(Modifier.padding(start = 8.dp)) {
                            Button(
                                onClick = { scope.launch { boost(); launchGame(g.packageName) } },
                                enabled = !cleaning
                            ) { Text("Boost & Main") }
                        }
                    }
                }
            }
        }
    }
}
